// Important: DO NOT remove this `ErrorBoundary` component.
class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo.componentStack);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-slate-50">
          <div className="text-center p-8 bg-white rounded-xl shadow-xl">
            <h1 className="text-2xl font-bold text-slate-900 mb-4">Something went wrong</h1>
            <p className="text-slate-600 mb-4">We're sorry, but something unexpected happened.</p>
            <button
              onClick={() => window.location.reload()}
              className="px-4 py-2 bg-slate-900 text-white rounded-lg"
            >
              Reload Page
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

function App() {
    try {
    const [showSplash, setShowSplash] = React.useState(true);
    const [currentUser, setCurrentUser] = React.useState(null);

    // Splash Logic
    React.useEffect(() => {
        // Simulate loading / Branding delay
        const timer = setTimeout(() => {
            setShowSplash(false);
        }, 2500);
        return () => clearTimeout(timer);
    }, []);

    // Auth Logic
    const handleLogin = (user) => {
        setCurrentUser(user);
        Storage.init(user.id); // Init storage for this specific account ID
        loadData();
    };

    const handleLogout = () => {
        setCurrentUser(null);
        Storage.accountId = null;
        setData({ counties: [], areas: [], apartments: [], houses: [], tenants: [], payments: [], history: [] });
    };

    const [data, setData] = React.useState({
        counties: [],
        areas: [],
        apartments: [],
        houses: [],
        tenants: [],
        payments: [],
        history: [] // { id, houseId, tenantId, tenantName, startDate, endDate }
    });
    
    const [settings, setSettings] = React.useState({
        managementName: 'Nart Management',
        address: '',
        phone: '',
        fontSize: 100
    });

    // Apply Font Size Effect
    React.useLayoutEffect(() => {
        const root = document.documentElement;
        if (settings.fontSize) {
            root.style.fontSize = `${settings.fontSize}%`; 
        } else {
            root.style.fontSize = '100%';
        }
    }, [settings.fontSize]);

    const loadData = () => {
        if (!Storage.accountId) return;
        const loadedData = {
            counties: Storage.get('counties', []),
            areas: Storage.get('areas', []),
            apartments: Storage.get('apartments', []),
            houses: Storage.get('houses', []),
            tenants: Storage.get('tenants', []),
            payments: Storage.get('payments', []),
            history: Storage.get('history', [])
        };
        
        // Auto-cleanup orphans on load - CAREFUL with history now
        // We don't want to delete tenants if they are in history but not in house
        // For now, let's trust the Move Out logic and only cleanup truly orphaned records if parents are deleted
        
        setData(loadedData);
        setSettings(Storage.get('settings', { managementName: 'Nart Management', fontSize: 100 }));
    };

    // UI State
    const [isDark, setIsDark] = React.useState(false);
    const [activeTab, setActiveTab] = React.useState('dashboard');
    const [isSidebarOpen, setIsSidebarOpen] = React.useState(window.innerWidth >= 768);
    const [selectedHouseId, setSelectedHouseId] = React.useState(null);
    const [receiptData, setReceiptData] = React.useState(null);
    const [notifications, setNotifications] = React.useState([]);

    // Check for overdue payments and generate notifications
    React.useEffect(() => {
        checkOverduePayments();
    }, [data.payments, data.houses, data.tenants]);

    const checkOverduePayments = () => {
        const newNotifications = [];
        
        data.houses.forEach(house => {
            if (house.tenantId) {
                const tenant = data.tenants.find(t => t.id === house.tenantId);
                if (!tenant) return;

                if (PaymentHelper.isOverdue(tenant, data.payments)) {
                    const dueDay = PaymentHelper.getDueDay(tenant);
                    const nextDue = PaymentHelper.getNextDuePeriod(tenant, data.payments);
                    
                    newNotifications.push({
                        id: `notif-${house.id}-${nextDue.month}-${nextDue.year}`,
                        type: 'overdue',
                        title: 'Rent Overdue',
                        message: `${tenant.name} (House ${house.number}) needs to pay for ${PaymentHelper.formatPeriod(nextDue.month, nextDue.year)}. Due date: ${dueDay}${PaymentHelper.getOrdinalSuffix(dueDay)}.`,
                        time: 'Action Required',
                        read: false
                    });
                }
            }
        });
        setNotifications(newNotifications);
    };

    // Theme Handler
    const toggleTheme = () => {
        setIsDark(!isDark);
        document.documentElement.classList.toggle('dark');
    };

    const toggleSidebar = () => setIsSidebarOpen(!isSidebarOpen);

    // Actions
    const handleAddCounty = () => {
        const name = prompt("Enter County Name:");
        if (name) {
            const newCounty = { id: 'cty-' + Date.now(), name };
            const newData = { ...data, counties: [...data.counties, newCounty] };
            Storage.set('counties', newData.counties);
            setData(newData);
        }
    };

    const handleAddArea = (countyId) => {
        const name = prompt("Enter Area Name:");
        if (name) {
            const newArea = { id: 'area-' + Date.now(), countyId, name };
            const newData = { ...data, areas: [...data.areas, newArea] };
            Storage.set('areas', newData.areas);
            setData(newData);
        }
    };

    const handleAddApartment = (areaId) => {
        const name = prompt("Enter Apartment Name:");
        if (name) {
            const newApt = { id: 'apt-' + Date.now(), areaId, name };
            const newData = { ...data, apartments: [...data.apartments, newApt] };
            Storage.set('apartments', newData.apartments);
            setData(newData);
        }
    };

    const handleAddHouse = (aptId) => {
        const number = prompt("Enter House Number:");
        const rent = prompt("Enter Rent Amount:", "1200");
        if (number && rent) {
            const newHouse = { 
                id: 'house-' + Date.now(), 
                apartmentId: aptId, 
                number, 
                rentAmount: Number(rent), 
                tenantId: null 
            };
            const newData = { ...data, houses: [...data.houses, newHouse] };
            Storage.set('houses', newData.houses);
            setData(newData);
        }
    };
    
    // Deletion Actions - Strict Cascading Delete
    const handleDeleteArea = (id) => {
        if(confirm("Permanently delete this area? ALL apartments, houses, and tenant data within it will be erased forever.")) {
            // 1. Find apartments in area
            const aptIds = data.apartments.filter(a => a.areaId === id).map(a => a.id);
            
            // 2. Find houses in those apartments
            const housesToDelete = data.houses.filter(h => aptIds.includes(h.apartmentId));
            const houseIds = housesToDelete.map(h => h.id);
            const tenantIdsToDelete = housesToDelete.map(h => h.tenantId).filter(tid => tid); // valid tenant IDs

            // 3. Filter Data
            const newAreas = data.areas.filter(a => a.id !== id);
            const newApartments = data.apartments.filter(a => !aptIds.includes(a.id));
            const newHouses = data.houses.filter(h => !houseIds.includes(h.id));
            const newTenants = data.tenants.filter(t => !tenantIdsToDelete.includes(t.id));
            const newPayments = data.payments.filter(p => !tenantIdsToDelete.includes(p.tenantId));

            const newData = {
                ...data,
                areas: newAreas,
                apartments: newApartments,
                houses: newHouses,
                tenants: newTenants,
                payments: newPayments
            };

            Storage.set('areas', newData.areas);
            Storage.set('apartments', newData.apartments);
            Storage.set('houses', newData.houses);
            Storage.set('tenants', newData.tenants);
            Storage.set('payments', newData.payments);
            
            setData(newData);
            setSelectedHouseId(null);
        }
    };

    const handleDeleteApartment = (id) => {
        if(confirm("Permanently delete this apartment? All houses and tenant data within it will be erased forever.")) {
            // 1. Find houses
            const housesToDelete = data.houses.filter(h => h.apartmentId === id);
            const houseIds = housesToDelete.map(h => h.id);
            const tenantIdsToDelete = housesToDelete.map(h => h.tenantId).filter(tid => tid);

            // 2. Filter Data
            const newApartments = data.apartments.filter(a => a.id !== id);
            const newHouses = data.houses.filter(h => !houseIds.includes(h.id));
            const newTenants = data.tenants.filter(t => !tenantIdsToDelete.includes(t.id));
            const newPayments = data.payments.filter(p => !tenantIdsToDelete.includes(p.tenantId));

            const newData = {
                ...data,
                apartments: newApartments,
                houses: newHouses,
                tenants: newTenants,
                payments: newPayments
            };

            Storage.set('apartments', newData.apartments);
            Storage.set('houses', newData.houses);
            Storage.set('tenants', newData.tenants);
            Storage.set('payments', newData.payments);

            setData(newData);
            setSelectedHouseId(null);
        }
    };

    const handleDeleteHouse = (id) => {
         if(confirm("Permanently delete this house? The tenant and all payment records will be erased.")) {
            const house = data.houses.find(h => h.id === id);
            const tenantId = house?.tenantId;

            // Filter Data
            const newHouses = data.houses.filter(h => h.id !== id);
            let newTenants = data.tenants;
            let newPayments = data.payments;

            if (tenantId) {
                newTenants = data.tenants.filter(t => t.id !== tenantId);
                newPayments = data.payments.filter(p => p.tenantId !== tenantId);
            }

            const newData = {
                ...data,
                houses: newHouses,
                tenants: newTenants,
                payments: newPayments
            };

            Storage.set('houses', newData.houses);
            Storage.set('tenants', newData.tenants);
            Storage.set('payments', newData.payments);

            setData(newData);
            setSelectedHouseId(null);
         }
    };

    // Tenant Management
    const handleSelectHouse = (houseId) => {
        const house = data.houses.find(h => h.id === houseId);
        if (!house.tenantId) {
            // Open House Details instead of auto-prompting
            setSelectedHouseId(houseId);
        } else {
            setSelectedHouseId(houseId);
        }
    };
    
    const handleAddTenantToHouse = (houseId) => {
        const name = prompt("Enter new tenant name:");
        if (name) {
            const idNumber = prompt("ID / Passport Number:");
            const phone = prompt("Phone Number:", "");
            const email = prompt("Email (Optional):", "");
            const deposit = prompt("Security Deposit Amount:", "0");

            const tenantId = 't-' + Date.now();
            const newTenant = {
                id: tenantId,
                name,
                idNumber,
                phone,
                email,
                deposit: Number(deposit),
                joinedDate: new Date().toISOString()
            };
            
            // Update Tenant List
            const updatedTenants = [...data.tenants, newTenant];
            
            // Update House Link
            const updatedHouses = data.houses.map(h => 
                h.id === houseId ? { ...h, tenantId } : h
            );

            Storage.set('tenants', updatedTenants);
            Storage.set('houses', updatedHouses);
            setData({ ...data, tenants: updatedTenants, houses: updatedHouses });
        }
    };

    const handleMoveOutTenant = (houseId, tenantId) => {
        if (confirm("Move this tenant out? Data will be archived in house history.")) {
            const tenant = data.tenants.find(t => t.id === tenantId);
            
            // 1. Create History Record
            const historyRecord = {
                id: 'hist-' + Date.now(),
                houseId: houseId,
                tenantId: tenantId,
                tenantName: tenant.name,
                startDate: tenant.joinedDate,
                endDate: new Date().toISOString()
            };
            
            // 2. Remove tenant from house (make vacant)
            const updatedHouses = data.houses.map(h => 
                h.id === houseId ? { ...h, tenantId: null } : h
            );
            
            // We DO NOT delete the tenant record or payments, so they persist in history
            // But we might want to flag the tenant as "inactive" generally if they left the system entirely?
            // For now, just unlinking them is enough.
            
            const updatedHistory = [...data.history, historyRecord];

            Storage.set('houses', updatedHouses);
            Storage.set('history', updatedHistory);
            
            setData({ 
                ...data, 
                houses: updatedHouses, 
                history: updatedHistory
            });
        }
    };

    const handleAddPayment = (paymentData) => {
        // Enrich with houseId snapshot (find house by tenantId)
        // If tenant is currently in a house, use that. If history payment, it might be trickier, but usually we pay for current.
        const house = data.houses.find(h => h.tenantId === paymentData.tenantId);
        const tenant = data.tenants.find(t => t.id === paymentData.tenantId);
        
        const newPayment = { 
            id: 'pay-' + Date.now(), 
            ...paymentData,
            houseId: house ? house.id : null, // Critical for house history
            tenantNameSnapshot: tenant ? tenant.name : 'Unknown'
        };
        
        const updatedPayments = [...data.payments, newPayment];
        Storage.set('payments', updatedPayments);
        setData({ ...data, payments: updatedPayments });
    };

    const handleGenerateReceipt = (payment) => {
        const tenant = data.tenants.find(t => t.id === payment.tenantId);
        const house = data.houses.find(h => h.tenantId === tenant.id) || data.houses.find(h => h.id === selectedHouseId); 
        
        const currentHouse = data.houses.find(h => h.tenantId === tenant.id);
        if (currentHouse) {
            const apartment = data.apartments.find(a => a.id === currentHouse.apartmentId);
            const area = data.areas.find(a => a.id === apartment.areaId);
            setReceiptData({ payment, tenant, house: currentHouse, apartment, area });
        } else {
            alert("Cannot generate receipt for past tenancy in this version.");
        }
    };
    
    const handleSaveSettings = (newSettings) => {
        setSettings(newSettings);
        Storage.set('settings', newSettings);
        alert('Settings saved successfully!');
    };

    const handleResetData = () => {
        const confirmWord = prompt("Type 'DELETE' to confirm wiping all data. This cannot be undone.");
        if (confirmWord === 'DELETE') {
            const emptyData = {
                areas: [],
                apartments: [],
                houses: [],
                tenants: [],
                payments: []
            };
            
            Storage.set('areas', []);
            Storage.set('apartments', []);
            Storage.set('houses', []);
            Storage.set('tenants', []);
            Storage.set('payments', []);
            // Don't clear settings
            
            setData(emptyData);
            setReceiptData(null);
            setSelectedHouseId(null);
            alert("System reset complete.");
        }
    };

    // Navigation Render
    const renderContent = () => {
        switch(activeTab) {
            case 'dashboard':
                return <Dashboard {...data} settings={settings} />;
            case 'properties':
                return <PropertyManager 
                    data={data} 
                    onSelectHouse={handleSelectHouse}
                    onAddCounty={handleAddCounty}
                    onAddArea={handleAddArea}
                    onDeleteArea={handleDeleteArea}
                    onAddApartment={handleAddApartment}
                    onDeleteApartment={handleDeleteApartment}
                    onAddHouse={handleAddHouse}
                    onDeleteHouse={handleDeleteHouse}
                />;
            case 'tenants':
                return <div className="p-6 text-center text-slate-500">Please use the Search bar or Property view to find tenants.</div>;
            case 'settings':
                return <Settings settings={settings} onSave={handleSaveSettings} onReset={handleResetData} currentUser={currentUser} onLogout={handleLogout} />;
            default:
                return <Dashboard {...data} />;
        }
    };

    // Prepare selected house data
    const selectedHouse = selectedHouseId ? data.houses.find(h => h.id === selectedHouseId) : null;
    const selectedTenant = selectedHouse?.tenantId ? data.tenants.find(t => t.id === selectedHouse.tenantId) : null;
    const houseHistory = selectedHouseId ? data.history.filter(h => h.houseId === selectedHouseId) : [];
    
    // Tenant Profile Modal State
    const [showTenantProfile, setShowTenantProfile] = React.useState(false);
    
    if (!currentUser) {
        return (
            <>
                 <SplashScreen isVisible={showSplash} />
                 <Login onLogin={handleLogin} />
            </>
        );
    }

    return (
      <div className="flex min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 font-sans transition-colors duration-200" data-name="app" data-file="app.js">
        <Sidebar 
            activeTab={activeTab} 
            setActiveTab={setActiveTab} 
            isSidebarOpen={isSidebarOpen} 
            closeSidebar={() => setIsSidebarOpen(false)}
            openSidebar={() => setIsSidebarOpen(true)}
        />
        
        <div className="flex-1 flex flex-col h-screen overflow-hidden">
            <Header 
                toggleTheme={toggleTheme} 
                isDark={isDark}
                toggleSidebar={toggleSidebar}
                notifications={notifications}
                onSearch={(term) => {
                    // Basic search implementation
                    if (!term) return;
                    const found = data.tenants.find(t => t.name.toLowerCase().includes(term.toLowerCase()));
                    if (found) {
                        const house = data.houses.find(h => h.tenantId === found.id);
                        if (house) {
                            setActiveTab('properties');
                            handleSelectHouse(house.id);
                        }
                    }
                }}
            />
            
            <main className="flex-1 overflow-y-auto p-6">
                {renderContent()}
            </main>
        </div>

        {/* Modals */}
        {selectedHouseId && (
            <HouseDetails 
                house={selectedHouse}
                tenant={selectedTenant}
                history={houseHistory}
                payments={data.payments}
                onClose={() => setSelectedHouseId(null)}
                onMoveOut={handleMoveOutTenant}
                onOpenTenantProfile={() => setShowTenantProfile(true)}
                onAddTenant={() => handleAddTenantToHouse(selectedHouseId)}
            />
        )}

        {showTenantProfile && selectedTenant && selectedHouse && (
             <TenantProfile 
                tenantId={selectedTenant.id}
                house={{...selectedHouse, tenant: selectedTenant}}
                payments={data.payments}
                settings={settings}
                onClose={() => setShowTenantProfile(false)}
                onAddPayment={handleAddPayment}
                onDeleteTenant={(hid, tid) => {
                    handleMoveOutTenant(hid, tid);
                    setShowTenantProfile(false); // Close profile, HouseDetails will update
                }}
                onGenerateReceipt={handleGenerateReceipt}
            />
        )}

        {receiptData && (
            <ReceiptView 
                data={receiptData} 
                settings={settings}
                onClose={() => setReceiptData(null)} 
            />
        )}
      </div>
    );
  } catch (error) {
    console.error('App component error:', error);
    return null;
  }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <ErrorBoundary>
    <App />
  </ErrorBoundary>
);