function Dashboard({ counties, areas, apartments, houses, tenants, payments, settings }) {
    // Calculate stats
    const totalProperties = houses.length;
    const occupied = houses.filter(h => h.tenantId).length;
    const vacancies = totalProperties - occupied;
    const occupancyRate = totalProperties > 0 ? Math.round((occupied / totalProperties) * 100) : 0;

    const currentMonth = new Date().getMonth() + 1;
    const currentYear = new Date().getFullYear();

    const monthlyRevenue = payments
        .filter(p => p.month === currentMonth && p.year === currentYear)
        .reduce((sum, p) => sum + p.amount, 0);

    // Prepare Chart Data
    const chartRef = React.useRef(null);
    const chartInstance = React.useRef(null);

    // Force re-render key based on data length to ensure canvas cleanliness
    const chartKey = React.useMemo(() => `chart-${areas.length}-${houses.length}-${payments.length}-${settings?.fontSize}`, [areas.length, houses.length, payments.length, settings?.fontSize]);

    React.useEffect(() => {
        // Strict cleanup
        if (chartInstance.current) {
            chartInstance.current.destroy();
            chartInstance.current = null;
        }

        const canvas = chartRef.current;
        if (!canvas) return;

        const ctx = canvas.getContext('2d');
        
        const areaLabels = areas.map(a => a.name);
        
        const paidData = [];
        const pendingData = []; // Red: Occupied but unpaid/overdue
        const vacantData = [];  // Yellow: Vacant

        areas.forEach(area => {
            // Get all apartments in this area
            const areaAptIds = apartments.filter(apt => apt.areaId === area.id).map(apt => apt.id);
            // Get all houses in these apartments
            const areaHouses = houses.filter(h => areaAptIds.includes(h.apartmentId));
            
            let paidCount = 0;
            let pendingCount = 0;
            let vacantCount = 0;

            areaHouses.forEach(house => {
                if (!house.tenantId) {
                    vacantCount++;
                } else {
                    const hasPaid = payments.some(p => 
                        p.tenantId === house.tenantId && 
                        p.month === currentMonth && 
                        p.year === currentYear
                    );
                    if (hasPaid) {
                        paidCount++;
                    } else {
                        pendingCount++; // Includes both strictly overdue and just 'not yet paid' for simplicity in chart as Red
                    }
                }
            });

            paidData.push(paidCount);
            pendingData.push(pendingCount);
            vacantData.push(vacantCount);
        });

        // Calculate dynamic font size
        // Base size 12px * ratio
        const baseSize = 12;
        const scaleRatio = (settings?.fontSize || 100) / 100;
        const scaledFontSize = Math.round(baseSize * scaleRatio);

        const commonTickOptions = {
            color: document.documentElement.classList.contains('dark') ? '#cbd5e1' : '#64748b',
            font: { size: scaledFontSize }
        };

        chartInstance.current = new ChartJS(ctx, {
            type: 'bar',
            data: {
                labels: areaLabels,
                datasets: [
                    {
                        label: 'Paid (Green)',
                        data: paidData,
                        backgroundColor: '#22c55e', // Emerald 500
                        stack: 'Stack 0',
                    },
                    {
                        label: 'Unpaid/Pending (Red)',
                        data: pendingData,
                        backgroundColor: '#ef4444', // Red 500
                        stack: 'Stack 0',
                    },
                    {
                        label: 'Vacant (Yellow)',
                        data: vacantData,
                        backgroundColor: '#eab308', // Amber 500
                        stack: 'Stack 0',
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'top',
                        labels: { 
                            color: document.documentElement.classList.contains('dark') ? '#fff' : '#333',
                            font: { size: scaledFontSize }
                        }
                    },
                    title: {
                        display: false,
                        text: 'Area Payment Status'
                    }
                },
                scales: {
                    x: {
                        stacked: true,
                        ticks: commonTickOptions,
                        grid: { display: false }
                    },
                    y: {
                        stacked: true,
                        ticks: { ...commonTickOptions, stepSize: 1 },
                        grid: { color: document.documentElement.classList.contains('dark') ? '#334155' : '#e2e8f0' }
                    }
                }
            }
        });

        return () => {
            if (chartInstance.current) {
                chartInstance.current.destroy();
            }
        };
    }, [areas, apartments, houses, payments, currentMonth, currentYear]);

    // Time-based greeting logic
    const [greeting, setGreeting] = React.useState('');
    const [currentDateStr, setCurrentDateStr] = React.useState('');

    React.useEffect(() => {
        const updateTime = () => {
            const now = new Date();
            const hour = now.getHours();
            const dateOptions = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
            
            if (hour < 12) setGreeting('Good Morning');
            else if (hour < 18) setGreeting('Good Afternoon');
            else setGreeting('Good Evening');

            setCurrentDateStr(now.toLocaleDateString(undefined, dateOptions));
        };

        updateTime();
        const timer = setInterval(updateTime, 60000); // Update every minute
        return () => clearInterval(timer);
    }, []);

    return (
        <div className="space-y-6 animate-fade-in">
            <div className="flex flex-col md:flex-row md:justify-between md:items-end gap-4">
                <div>
                    <h2 className="text-3xl font-bold text-slate-800 dark:text-white mb-1">
                        {greeting}, Admin
                    </h2>
                    <p className="text-slate-500 dark:text-slate-400 flex items-center gap-2">
                        <span className="icon-calendar-days w-4 h-4"></span>
                        It's {currentDateStr}. Here's your daily overview.
                    </p>
                </div>
                <div className="hidden md:block">
                     {/* Placeholder for future actions if needed */}
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mt-6">
                <div className="card p-6 flex items-start justify-between border-l-4 border-l-sky-500">
                    <div>
                        <p className="text-sm text-slate-500 dark:text-slate-400 font-medium">Total Properties</p>
                        <h3 className="text-3xl font-bold text-slate-800 dark:text-white mt-1">{houses.length}</h3>
                    </div>
                    <div className="p-3 bg-sky-50 dark:bg-sky-900/20 rounded-lg">
                        <div className="icon-home w-6 h-6 text-sky-600 dark:text-sky-400"></div>
                    </div>
                </div>

                <div className="card p-6 flex items-start justify-between border-l-4 border-l-emerald-500">
                    <div>
                        <p className="text-sm text-slate-500 dark:text-slate-400 font-medium">Occupancy Rate</p>
                        <h3 className="text-3xl font-bold text-slate-800 dark:text-white mt-1">{occupancyRate}%</h3>
                        <p className="text-xs text-emerald-600 mt-1">{occupied} Occupied</p>
                    </div>
                    <div className="p-3 bg-emerald-50 dark:bg-emerald-900/20 rounded-lg">
                        <div className="icon-users w-6 h-6 text-emerald-600 dark:text-emerald-400"></div>
                    </div>
                </div>

                <div className="card p-6 flex items-start justify-between border-l-4 border-l-amber-500">
                    <div>
                        <p className="text-sm text-slate-500 dark:text-slate-400 font-medium">Vacancies</p>
                        <h3 className="text-3xl font-bold text-slate-800 dark:text-white mt-1">{vacancies}</h3>
                        <p className="text-xs text-amber-600 mt-1">Available now</p>
                    </div>
                    <div className="p-3 bg-amber-50 dark:bg-amber-900/20 rounded-lg">
                        <div className="icon-key w-6 h-6 text-amber-600 dark:text-amber-400"></div>
                    </div>
                </div>

                <div className="card p-6 flex items-start justify-between border-l-4 border-l-indigo-500">
                    <div>
                        <p className="text-sm text-slate-500 dark:text-slate-400 font-medium">Month Revenue</p>
                        <h3 className="text-3xl font-bold text-slate-800 dark:text-white mt-1">${monthlyRevenue.toLocaleString()}</h3>
                        <p className="text-xs text-indigo-600 mt-1">{new Date().toLocaleString('default', { month: 'long' })}</p>
                    </div>
                    <div className="p-3 bg-indigo-50 dark:bg-indigo-900/20 rounded-lg">
                        <div className="icon-wallet w-6 h-6 text-indigo-600 dark:text-indigo-400"></div>
                    </div>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Chart Section - New */}
                <div className="card p-6 lg:col-span-3">
                    <h3 className="text-lg font-semibold mb-4 text-slate-800 dark:text-white">Area Payment Overview</h3>
                    <div className="h-[300px] w-full" key={chartKey}>
                        <canvas ref={chartRef}></canvas>
                    </div>
                </div>

                <div className="card p-6 lg:col-span-2">
                    <h3 className="text-lg font-semibold mb-4 text-slate-800 dark:text-white">Recent Activity</h3>
                    <div className="space-y-4">
                        {payments.slice(0, 5).map(payment => {
                            const tenant = tenants.find(t => t.id === payment.tenantId);
                            return (
                                <div key={payment.id} className="flex items-center justify-between p-3 hover:bg-slate-50 dark:hover:bg-slate-750 rounded-lg transition-colors border-b border-slate-100 dark:border-slate-700 last:border-0">
                                    <div className="flex items-center gap-3">
                                        <div className="w-10 h-10 rounded-full bg-green-100 dark:bg-green-900/30 flex items-center justify-center">
                                            <div className="icon-dollar-sign w-5 h-5 text-green-600 dark:text-green-400"></div>
                                        </div>
                                        <div>
                                            <p className="font-medium text-slate-800 dark:text-slate-200">Payment Received</p>
                                            <p className="text-sm text-slate-500">From {tenant ? tenant.name : 'Unknown'} for {new Date(0, payment.month - 1).toLocaleString('default', { month: 'long' })}</p>
                                        </div>
                                    </div>
                                    <span className="font-bold text-slate-700 dark:text-slate-300">+${payment.amount}</span>
                                </div>
                            )
                        })}
                    </div>
                </div>

                <div className="card p-6">
                    <h3 className="text-lg font-semibold mb-4 text-slate-800 dark:text-white">Area Details</h3>
                    <div className="space-y-3">
                        {areas.map(area => {
                            // Calc total properties
                            const areaAptIds = apartments.filter(apt => apt.areaId === area.id).map(apt => apt.id);
                            const totalHouses = houses.filter(h => areaAptIds.includes(h.apartmentId)).length;
                            
                            return (
                                <div key={area.id} className="flex items-center justify-between p-2 hover:bg-slate-50 dark:hover:bg-slate-700/50 rounded transition-colors">
                                    <div className="flex items-center gap-3">
                                        <div className="w-8 h-8 rounded bg-slate-100 dark:bg-slate-700 flex items-center justify-center">
                                            <div className="icon-map-pin w-4 h-4 text-slate-500 dark:text-slate-400"></div>
                                        </div>
                                        <div>
                                            <div className="font-medium text-slate-700 dark:text-slate-300">{area.name}</div>
                                            <div className="text-xs text-slate-400">{totalHouses} Properties</div>
                                        </div>
                                    </div>
                                </div>
                            )
                        })}
                    </div>
                </div>
            </div>
        </div>
    );
}