function Header({ toggleTheme, isDark, toggleSidebar, onSearch, notifications = [] }) {
    const [searchTerm, setSearchTerm] = React.useState('');
    const [showNotifications, setShowNotifications] = React.useState(false);
    
    const handleSearch = (e) => {
        const val = e.target.value;
        setSearchTerm(val);
        onSearch(val);
    };

    // Get current date time formatted
    const [dateTime, setDateTime] = React.useState(new Date());

    React.useEffect(() => {
        const timer = setInterval(() => setDateTime(new Date()), 1000);
        return () => clearInterval(timer);
    }, []);

    return (
        <header className="h-16 bg-white dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700 flex items-center justify-between px-4 md:px-6 sticky top-0 z-20 no-print">
            <div className="flex items-center gap-4 flex-1 md:w-1/3">
                <button 
                    onClick={toggleSidebar}
                    className="p-2 -ml-2 mr-2 rounded-lg text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-700 md:hidden"
                >
                    <div className="icon-menu w-6 h-6"></div>
                </button>

                <div className="relative w-full max-w-md">
                    <div className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400">
                        <div className="icon-search w-4 h-4"></div>
                    </div>
                    <input 
                        type="text" 
                        placeholder="Search tenants..." 
                        className="input-field pl-10"
                        value={searchTerm}
                        onChange={handleSearch}
                    />
                </div>
            </div>

            <div className="flex items-center gap-6">
                {/* Notification Bell */}
                <div className="relative">
                    <button 
                        onClick={() => setShowNotifications(!showNotifications)}
                        className="p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 transition-colors relative"
                    >
                        <div className="icon-bell w-5 h-5"></div>
                        {notifications.length > 0 && (
                            <span className="absolute top-1 right-1 w-2.5 h-2.5 bg-red-500 rounded-full border-2 border-white dark:border-slate-800"></span>
                        )}
                    </button>

                    {showNotifications && (
                        <>
                            <div className="fixed inset-0 z-30" onClick={() => setShowNotifications(false)}></div>
                            <div className="absolute right-0 mt-2 w-80 bg-white dark:bg-slate-800 rounded-xl shadow-xl border border-slate-200 dark:border-slate-700 z-40 overflow-hidden animate-fade-in">
                                <div className="p-3 border-b border-slate-200 dark:border-slate-700 flex justify-between items-center bg-slate-50 dark:bg-slate-900/50">
                                    <h3 className="font-semibold text-sm text-slate-800 dark:text-white">Notifications</h3>
                                    <span className="text-xs text-slate-500 bg-slate-200 dark:bg-slate-700 px-1.5 py-0.5 rounded-full">{notifications.length}</span>
                                </div>
                                <div className="max-h-[300px] overflow-y-auto">
                                    {notifications.length === 0 ? (
                                        <div className="p-6 text-center text-slate-500 text-sm">
                                            <div className="icon-bell-off w-8 h-8 mx-auto mb-2 opacity-50"></div>
                                            No new notifications
                                        </div>
                                    ) : (
                                        notifications.map((notif, idx) => (
                                            <div key={idx} className="p-3 border-b border-slate-100 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-750 transition-colors">
                                                <div className="flex gap-3">
                                                    <div className="mt-1 flex-shrink-0">
                                                        <div className="w-8 h-8 rounded-full bg-red-100 dark:bg-red-900/30 flex items-center justify-center text-red-600 dark:text-red-400">
                                                            <div className="icon-alert-circle w-4 h-4"></div>
                                                        </div>
                                                    </div>
                                                    <div>
                                                        <p className="text-sm font-semibold text-slate-800 dark:text-slate-200">{notif.title}</p>
                                                        <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">{notif.message}</p>
                                                        <p className="text-[10px] text-slate-400 mt-1 uppercase tracking-wide">{notif.time}</p>
                                                    </div>
                                                </div>
                                            </div>
                                        ))
                                    )}
                                </div>
                            </div>
                        </>
                    )}
                </div>

                <div className="text-right hidden md:block">
                    <div className="text-sm font-semibold text-slate-800 dark:text-slate-200">
                        {dateTime.toLocaleDateString(undefined, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
                    </div>
                    <div className="text-xs text-slate-500 dark:text-slate-400 font-mono">
                        {dateTime.toLocaleTimeString()}
                    </div>
                </div>

                <button 
                    onClick={toggleTheme}
                    className="p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 transition-colors"
                    title="Toggle Theme"
                >
                    {isDark ? <div className="icon-sun w-5 h-5"></div> : <div className="icon-moon w-5 h-5"></div>}
                </button>
            </div>
        </header>
    );
}
