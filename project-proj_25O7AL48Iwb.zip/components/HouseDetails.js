function HouseDetails({ 
    house, 
    tenant, 
    history = [], 
    payments = [], 
    onClose, 
    onMoveOut, 
    onOpenTenantProfile,
    onAddTenant 
}) {
    // Sort history: newest first
    const timeline = [
        // Current occupancy (if any)
        ...(tenant ? [{
            type: 'current',
            tenantName: tenant.name,
            startDate: tenant.joinedDate,
            endDate: 'Present',
            isActive: true
        }] : []),
        // Past history
        ...history.map(h => ({
            type: 'past',
            tenantName: h.tenantName,
            startDate: h.startDate,
            endDate: h.endDate,
            isActive: false
        }))
    ].sort((a, b) => new Date(b.startDate) - new Date(a.startDate));

    // Determine Vacant periods (gaps between occupancies)
    const fullTimeline = [];
    for (let i = 0; i < timeline.length; i++) {
        fullTimeline.push(timeline[i]);
        
        // If there is a next item, check for gap
        if (i < timeline.length - 1) {
            const currentEnd = new Date(timeline[i].endDate === 'Present' ? new Date() : timeline[i].endDate);
            const nextStart = new Date(timeline[i+1].startDate); // Older record
            
            // If gap is more than 1 day
            const gapDays = (currentEnd - nextStart) / (1000 * 60 * 60 * 24);
            // Actually, loop is Newest -> Oldest. 
            // timeline[i] is NEWER. timeline[i+1] is OLDER.
            // Gap is between timeline[i+1].endDate and timeline[i].startDate
            
            const olderEnd = new Date(timeline[i+1].endDate);
            const newerStart = new Date(timeline[i].startDate);
            
            if (newerStart > olderEnd) {
                fullTimeline.push({
                    type: 'vacant',
                    startDate: olderEnd.toISOString(),
                    endDate: newerStart.toISOString(),
                    isActive: false
                });
            }
        }
    }

    const housePayments = payments.filter(p => p.houseId === house.id).sort((a,b) => new Date(b.date) - new Date(a.date));

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-sm animate-fade-in">
            <div className="bg-white dark:bg-slate-900 w-full max-w-4xl rounded-xl shadow-2xl max-h-[90vh] overflow-y-auto flex flex-col">
                {/* Header */}
                <div className="p-6 border-b border-slate-200 dark:border-slate-700 flex justify-between items-start bg-white dark:bg-slate-900 sticky top-0 z-10">
                    <div>
                        <div className="flex items-center gap-3">
                            <h2 className="text-2xl font-bold text-slate-800 dark:text-white">House {house.number}</h2>
                            {tenant ? (
                                <span className="px-2 py-1 bg-emerald-100 text-emerald-700 text-xs font-bold rounded uppercase">Occupied</span>
                            ) : (
                                <span className="px-2 py-1 bg-amber-100 text-amber-700 text-xs font-bold rounded uppercase">Vacant</span>
                            )}
                        </div>
                        <p className="text-slate-500 dark:text-slate-400 mt-1">
                            Rent: ${house.rentAmount}/month
                        </p>
                    </div>
                    <button onClick={onClose} className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full">
                        <div className="icon-x w-6 h-6"></div>
                    </button>
                </div>

                <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-8">
                    
                    {/* Left: Current Status & Actions */}
                    <div className="space-y-6">
                        <div className="card p-5 border-l-4 border-l-sky-500">
                            <h3 className="font-bold text-lg mb-4">Current Occupant</h3>
                            {tenant ? (
                                <div>
                                    <div className="flex items-center gap-4 mb-4">
                                        <div className="w-12 h-12 rounded-full bg-sky-100 flex items-center justify-center text-sky-600 font-bold text-xl">
                                            {tenant.name.charAt(0)}
                                        </div>
                                        <div>
                                            <h4 className="font-bold text-slate-800 dark:text-white">{tenant.name}</h4>
                                            <p className="text-sm text-slate-500">{tenant.phone}</p>
                                        </div>
                                    </div>
                                    
                                    <div className="grid grid-cols-2 gap-3 mb-4">
                                        <button 
                                            onClick={onOpenTenantProfile}
                                            className="btn btn-primary w-full text-sm"
                                        >
                                            <div className="icon-user w-4 h-4"></div> Profile & Pay
                                        </button>
                                        <button 
                                            onClick={() => onMoveOut(house.id, tenant.id)}
                                            className="btn btn-secondary w-full text-amber-600 hover:text-amber-700 border-amber-200 hover:bg-amber-50 text-sm"
                                        >
                                            <div className="icon-log-out w-4 h-4"></div> Move Out
                                        </button>
                                    </div>
                                </div>
                            ) : (
                                <div className="text-center py-6">
                                    <div className="icon-home w-12 h-12 mx-auto text-slate-300 mb-2"></div>
                                    <p className="text-slate-500 mb-4">This house is currently vacant.</p>
                                    <button onClick={onAddTenant} className="btn btn-primary w-full">
                                        <div className="icon-plus w-4 h-4"></div> Add New Tenant
                                    </button>
                                </div>
                            )}
                        </div>

                        <div className="card p-5">
                            <h3 className="font-bold text-lg mb-4">Occupancy History</h3>
                            <div className="space-y-0 relative border-l-2 border-slate-200 dark:border-slate-700 ml-3">
                                {fullTimeline.length === 0 && (
                                    <div className="pl-6 text-slate-500 italic">No history recorded.</div>
                                )}
                                {fullTimeline.map((item, idx) => (
                                    <div key={idx} className="mb-6 ml-6 relative">
                                        <div className={`absolute -left-[31px] top-1 w-4 h-4 rounded-full border-2 border-white dark:border-slate-800 
                                            ${item.type === 'current' ? 'bg-emerald-500' : item.type === 'vacant' ? 'bg-amber-400' : 'bg-slate-400'}
                                        `}></div>
                                        
                                        <div className="flex justify-between items-start">
                                            <div>
                                                <p className={`font-bold ${item.type === 'vacant' ? 'text-amber-600' : 'text-slate-800 dark:text-white'}`}>
                                                    {item.type === 'vacant' ? 'Vacant' : item.tenantName}
                                                </p>
                                                <p className="text-xs text-slate-500">
                                                    {new Date(item.startDate).toLocaleDateString()} - {item.endDate === 'Present' ? 'Present' : new Date(item.endDate).toLocaleDateString()}
                                                </p>
                                            </div>
                                            {item.type === 'current' && (
                                                <span className="text-[10px] bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded-full font-bold">NOW</span>
                                            )}
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>

                    {/* Right: House Payment History */}
                    <div className="card p-5 flex flex-col h-full">
                        <h3 className="font-bold text-lg mb-4">House Payment Log</h3>
                        <p className="text-xs text-slate-500 mb-4">Shows all payments made for this house, regardless of tenant.</p>
                        
                        <div className="flex-1 overflow-y-auto max-h-[400px] -mx-2 px-2">
                            {housePayments.length === 0 ? (
                                <div className="text-center py-10 text-slate-400">No payments recorded.</div>
                            ) : (
                                <table className="w-full text-sm text-left">
                                    <thead className="text-xs text-slate-500 bg-slate-50 dark:bg-slate-800 sticky top-0">
                                        <tr>
                                            <th className="py-2">Date</th>
                                            <th className="py-2">Tenant</th>
                                            <th className="py-2">Amount</th>
                                        </tr>
                                    </thead>
                                    <tbody className="divide-y divide-slate-100 dark:divide-slate-700">
                                        {housePayments.map(p => (
                                            <tr key={p.id}>
                                                <td className="py-2">{new Date(p.date).toLocaleDateString()}</td>
                                                <td className="py-2 font-medium">
                                                    {/* Find tenant name from history or current? For simplicity assuming tenant name might be needed but IDs are robust */}
                                                    {/* We could store tenantName snapshop in payment for historical accuracy, but standard ref is ok */}
                                                    {p.tenantNameSnapshot || 'Tenant'} 
                                                </td>
                                                <td className="py-2 font-bold text-emerald-600">${p.amount}</td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            )}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}