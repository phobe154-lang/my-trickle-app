function PaymentModal({ house, tenant, targetPeriod, onClose, onSubmit }) {
    const [amount, setAmount] = React.useState(house.rentAmount);
    const [date, setDate] = React.useState(new Date().toISOString().split('T')[0]);
    
    // Lock to target period if provided (Strict Sequential Mode)
    const [month, setMonth] = React.useState(targetPeriod ? targetPeriod.month : new Date().getMonth() + 1);
    const [year, setYear] = React.useState(targetPeriod ? targetPeriod.year : new Date().getFullYear());
    
    const [paymentMethod, setPaymentMethod] = React.useState('M-Pesa');
    const [transactionCode, setTransactionCode] = React.useState('');
    const [notes, setNotes] = React.useState('');

    const handleSubmit = (e) => {
        e.preventDefault();
        onSubmit({
            tenantId: tenant.id,
            amount: Number(amount),
            date,
            month: Number(month),
            year: Number(year),
            paymentMethod,
            transactionCode,
            notes
        });
    };

    return (
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm animate-fade-in">
            <div className="bg-white dark:bg-slate-800 w-full max-w-md rounded-xl shadow-xl overflow-hidden">
                <div className="p-4 border-b border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900/50 flex justify-between items-center">
                    <h3 className="font-bold text-lg text-slate-800 dark:text-white">Record Payment</h3>
                    <button onClick={onClose} className="text-slate-400 hover:text-slate-600"><div className="icon-x w-5 h-5"></div></button>
                </div>
                
                <form onSubmit={handleSubmit} className="p-6 space-y-4">
                    <div>
                        <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Amount</label>
                        <div className="relative">
                            <span className="absolute left-3 top-2 text-slate-400">$</span>
                            <input 
                                type="number" 
                                required
                                className="input-field pl-7"
                                value={amount} 
                                onChange={e => setAmount(e.target.value)}
                            />
                        </div>
                    </div>

                    {/* Information Alert */}
                    <div className="bg-blue-50 dark:bg-blue-900/20 p-3 rounded-lg flex gap-3 items-start">
                        <div className="icon-info w-5 h-5 text-blue-600 dark:text-blue-400 shrink-0 mt-0.5"></div>
                        <div className="text-xs text-blue-800 dark:text-blue-200">
                            <strong>Sequential Payment Enforced:</strong> You are paying for 
                            <span className="font-bold mx-1 underline">
                                {new Date(year, month - 1).toLocaleString('default', {month: 'long', year: 'numeric'})}
                            </span> 
                            because previous months are settled.
                        </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                        <div className="opacity-70 pointer-events-none">
                            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">For Month</label>
                            <select className="input-field bg-slate-100 dark:bg-slate-800" value={month} readOnly>
                                {Array.from({length: 12}, (_, i) => (
                                    <option key={i+1} value={i+1}>{new Date(0, i).toLocaleString('default', {month: 'long'})}</option>
                                ))}
                            </select>
                        </div>
                        <div className="opacity-70 pointer-events-none">
                            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Year</label>
                            <input 
                                type="number" 
                                className="input-field bg-slate-100 dark:bg-slate-800"
                                value={year} 
                                readOnly
                            />
                        </div>
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Payment Date</label>
                        <input 
                            type="date" 
                            required
                            className="input-field"
                            value={date} 
                            onChange={e => setDate(e.target.value)}
                        />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Payment Method</label>
                            <select 
                                className="input-field"
                                value={paymentMethod} 
                                onChange={e => setPaymentMethod(e.target.value)}
                            >
                                <option value="M-Pesa">M-Pesa</option>
                                <option value="Bank">Bank</option>
                                <option value="Cash">Cash</option>
                            </select>
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Transaction Code</label>
                            <input 
                                type="text" 
                                className="input-field"
                                value={transactionCode} 
                                onChange={e => setTransactionCode(e.target.value)}
                                placeholder={paymentMethod === 'Cash' ? 'N/A' : 'e.g. QKD8...'}
                            />
                        </div>
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Notes (Optional)</label>
                        <textarea 
                            className="input-field min-h-[80px]"
                            value={notes} 
                            onChange={e => setNotes(e.target.value)}
                            placeholder="Additional comments..."
                        ></textarea>
                    </div>

                    <div className="pt-2">
                        <button type="submit" className="btn btn-primary w-full justify-center">
                            Save Payment
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
}