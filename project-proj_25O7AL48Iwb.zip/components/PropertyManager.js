function PropertyManager({ 
    data, 
    onSelectHouse,
    onAddCounty, 
    onAddArea, 
    onDeleteArea,
    onAddApartment,
    onDeleteApartment,
    onAddHouse,
    onDeleteHouse 
}) {
    const { counties = [], areas, apartments, houses, tenants, payments } = data;
    const [selectedCountyId, setSelectedCountyId] = React.useState(null);
    const [selectedAreaId, setSelectedAreaId] = React.useState(null);
    const [selectedAptId, setSelectedAptId] = React.useState(null);

    // Helpers
    const getAreasInCounty = (countyId) => areas.filter(a => a.countyId === countyId);
    const getApartmentsInArea = (areaId) => apartments.filter(a => a.areaId === areaId);
    const getHousesInApartment = (aptId) => houses.filter(h => h.apartmentId === aptId);
    
    // Check payment status for a house/tenant
    const getHouseStatus = (house) => {
        if (!house.tenantId) return 'vacant'; // Yellow
        
        const tenant = tenants.find(t => t.id === house.tenantId);
        if (!tenant) return 'vacant'; // Fallback

        // Strict Check using PaymentHelper
        // If they are overdue (missed past month OR missed current month after due date) -> RED
        if (PaymentHelper.isOverdue(tenant, payments)) return 'overdue';

        // If they are NOT overdue, they might have paid for current month OR purely pending future date
        
        // Check if Current Month is paid?
        const today = new Date();
        const currentMonth = today.getMonth() + 1;
        const currentYear = today.getFullYear();

        const hasPaidCurrent = payments.some(p => 
            p.tenantId === house.tenantId && 
            p.month === currentMonth && 
            p.year === currentYear
        );

        if (hasPaidCurrent) return 'paid';

        // If not paid current, but NOT overdue (meaning before due date), it is 'pending'
        return 'pending';
    };

    const getStatusColor = (status) => {
        switch(status) {
            case 'vacant': return 'bg-amber-100 border-amber-300 text-amber-800 dark:bg-amber-900/30 dark:border-amber-700 dark:text-amber-200';
            case 'paid': return 'bg-emerald-100 border-emerald-300 text-emerald-800 dark:bg-emerald-900/30 dark:border-emerald-700 dark:text-emerald-200';
            case 'overdue': return 'bg-red-100 border-red-300 text-red-800 dark:bg-red-900/30 dark:border-red-700 dark:text-red-200'; // Red only if date passed
            case 'pending': return 'bg-blue-50 border-blue-200 text-blue-700 dark:bg-blue-900/20 dark:border-blue-800 dark:text-blue-300'; // Blue for pending but not overdue
            default: return 'bg-slate-100 border-slate-200 text-slate-800';
        }
    };

    return (
        <div className="space-y-6 h-full flex flex-col">
            {/* Breadcrumbs / Navigation */}
            <div className="flex items-center gap-2 text-sm text-slate-500 dark:text-slate-400 pb-4 border-b border-slate-200 dark:border-slate-700 flex-wrap">
                <button 
                    onClick={() => { setSelectedCountyId(null); setSelectedAreaId(null); setSelectedAptId(null); }}
                    className={`hover:text-sky-600 ${!selectedCountyId ? 'font-bold text-sky-600' : ''}`}
                >
                    Counties
                </button>
                
                {selectedCountyId && (
                    <>
                        <div className="icon-chevron-right w-4 h-4"></div>
                        <button 
                            onClick={() => { setSelectedAreaId(null); setSelectedAptId(null); }}
                            className={`hover:text-sky-600 ${!selectedAreaId ? 'font-bold text-sky-600' : ''}`}
                        >
                            {counties.find(c => c.id === selectedCountyId)?.name}
                        </button>
                    </>
                )}

                {selectedAreaId && (
                    <>
                        <div className="icon-chevron-right w-4 h-4"></div>
                        <button 
                            onClick={() => setSelectedAptId(null)}
                            className={`hover:text-sky-600 ${!selectedAptId ? 'font-bold text-sky-600' : ''}`}
                        >
                            {areas.find(a => a.id === selectedAreaId)?.name}
                        </button>
                    </>
                )}
                {selectedAptId && (
                    <>
                        <div className="icon-chevron-right w-4 h-4"></div>
                        <span className="font-bold text-sky-600">
                            {apartments.find(a => a.id === selectedAptId)?.name}
                        </span>
                    </>
                )}
            </div>

            {/* Level 0: Counties View */}
            {!selectedCountyId && (
                <div className="animate-fade-in">
                    <div className="flex justify-between items-center mb-4">
                        <h2 className="text-xl font-bold text-slate-800 dark:text-white">All Counties</h2>
                        <button onClick={() => onAddCounty()} className="btn btn-primary text-sm">
                            <div className="icon-plus w-4 h-4"></div> Add County
                        </button>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        {counties.map(county => (
                            <div 
                                key={county.id} 
                                onClick={() => setSelectedCountyId(county.id)}
                                className="card p-6 cursor-pointer hover:shadow-md transition-shadow group relative"
                            >
                                <div className="flex items-center justify-between mb-2">
                                    <h3 className="text-lg font-bold text-slate-800 dark:text-white">{county.name}</h3>
                                    <div className="icon-map-pin w-5 h-5 text-slate-400 group-hover:text-sky-500 transition-colors"></div>
                                </div>
                                <p className="text-sm text-slate-500">{getAreasInCounty(county.id).length} Areas</p>
                            </div>
                        ))}
                         {counties.length === 0 && (
                            <div className="col-span-full text-center py-10 text-slate-400 border-2 border-dashed border-slate-200 rounded-xl">
                                No counties found. Start by adding your first county.
                            </div>
                        )}
                    </div>
                </div>
            )}

            {/* Level 1: Areas View */}
            {selectedCountyId && !selectedAreaId && (
                <div className="animate-fade-in">
                    <div className="flex justify-between items-center mb-4">
                        <h2 className="text-xl font-bold text-slate-800 dark:text-white">
                            Areas in {counties.find(c => c.id === selectedCountyId)?.name}
                        </h2>
                        <button onClick={() => onAddArea(selectedCountyId)} className="btn btn-primary text-sm">
                            <div className="icon-plus w-4 h-4"></div> Add Area
                        </button>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        {getAreasInCounty(selectedCountyId).map(area => (
                            <div 
                                key={area.id} 
                                onClick={() => setSelectedAreaId(area.id)}
                                className="card p-6 cursor-pointer hover:shadow-md transition-shadow group relative"
                            >
                                <div className="flex items-center justify-between mb-2">
                                    <h3 className="text-lg font-bold text-slate-800 dark:text-white">{area.name}</h3>
                                    <div className="icon-map w-5 h-5 text-slate-400 group-hover:text-sky-500 transition-colors"></div>
                                </div>
                                <p className="text-sm text-slate-500">{getApartmentsInArea(area.id).length} Apartments</p>
                                
                                <button 
                                    onClick={(e) => { e.stopPropagation(); onDeleteArea(area.id); }}
                                    className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 p-1.5 rounded bg-red-50 text-red-500 hover:bg-red-100 transition-all"
                                    title="Delete Area"
                                >
                                    <div className="icon-trash w-4 h-4"></div>
                                </button>
                            </div>
                        ))}
                         {getAreasInCounty(selectedCountyId).length === 0 && (
                            <div className="col-span-full text-center py-10 text-slate-400 border-2 border-dashed border-slate-200 rounded-xl">
                                No areas in this county yet.
                            </div>
                        )}
                    </div>
                </div>
            )}

            {/* Level 2: Apartments View */}
            {selectedCountyId && selectedAreaId && !selectedAptId && (
                <div className="animate-fade-in">
                     <div className="flex justify-between items-center mb-4">
                        <h2 className="text-xl font-bold text-slate-800 dark:text-white">
                            Apartments in {areas.find(a => a.id === selectedAreaId)?.name}
                        </h2>
                        <button onClick={() => onAddApartment(selectedAreaId)} className="btn btn-primary text-sm">
                            <div className="icon-plus w-4 h-4"></div> Add Apartment
                        </button>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        {getApartmentsInArea(selectedAreaId).map(apt => (
                            <div 
                                key={apt.id} 
                                onClick={() => setSelectedAptId(apt.id)}
                                className="card p-6 cursor-pointer hover:shadow-md transition-shadow group relative"
                            >
                                <div className="flex items-center justify-between mb-2">
                                    <h3 className="text-lg font-bold text-slate-800 dark:text-white">{apt.name}</h3>
                                    <div className="icon-building w-5 h-5 text-slate-400 group-hover:text-sky-500 transition-colors"></div>
                                </div>
                                <p className="text-sm text-slate-500">{getHousesInApartment(apt.id).length} Houses</p>
                                
                                <button 
                                    onClick={(e) => { e.stopPropagation(); onDeleteApartment(apt.id); }}
                                    className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 p-1.5 rounded bg-red-50 text-red-500 hover:bg-red-100 transition-all"
                                    title="Delete Apartment"
                                >
                                    <div className="icon-trash w-4 h-4"></div>
                                </button>
                            </div>
                        ))}
                        {getApartmentsInArea(selectedAreaId).length === 0 && (
                            <div className="col-span-full text-center py-10 text-slate-400 border-2 border-dashed border-slate-200 rounded-xl">
                                No apartments yet. Add one to get started.
                            </div>
                        )}
                    </div>
                </div>
            )}

            {/* Level 3: Houses View */}
            {selectedAreaId && selectedAptId && (
                <div className="animate-fade-in">
                    <div className="flex justify-between items-center mb-4">
                        <h2 className="text-xl font-bold text-slate-800 dark:text-white">
                            Houses in {apartments.find(a => a.id === selectedAptId)?.name}
                        </h2>
                        <button onClick={() => onAddHouse(selectedAptId)} className="btn btn-primary text-sm">
                            <div className="icon-plus w-4 h-4"></div> Add House
                        </button>
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
                        {getHousesInApartment(selectedAptId).map(house => {
                            const status = getHouseStatus(house);
                            const colorClass = getStatusColor(status);
                            
                            return (
                                <div 
                                    key={house.id} 
                                    onClick={() => onSelectHouse(house.id)}
                                    className={`card p-4 cursor-pointer hover:scale-105 transition-transform relative border-2 ${colorClass}`}
                                >
                                    <div className="flex justify-between items-start">
                                        <span className="text-2xl font-bold opacity-80">{house.number}</span>
                                        {status === 'paid' && <div className="icon-check-circle w-5 h-5 text-emerald-600"></div>}
                                        {status === 'overdue' && <div className="icon-alert-circle w-5 h-5 text-red-600 animate-pulse"></div>}
                                        {status === 'pending' && <div className="icon-clock w-5 h-5 text-blue-600"></div>}
                                        {status === 'vacant' && <div className="icon-key w-5 h-5 text-amber-600"></div>}
                                    </div>
                                    <div className="mt-4">
                                        <p className="text-sm font-medium opacity-70">
                                            {status === 'vacant' ? 'Vacant' : tenants.find(t => t.id === house.tenantId)?.name || 'Unknown'}
                                        </p>
                                        <p className="text-xs opacity-60 font-mono mt-1">
                                            Rent: ${house.rentAmount}
                                        </p>
                                    </div>
                                    
                                    {/* Delete Button (Hover only) */}
                                    <button 
                                        onClick={(e) => { e.stopPropagation(); onDeleteHouse(house.id); }}
                                        className="absolute top-2 right-2 p-1.5 rounded-full bg-white/80 hover:bg-red-100 text-slate-400 hover:text-red-500 opacity-0 hover:opacity-100 transition-all shadow-sm z-10"
                                        title="Delete House"
                                    >
                                        <div className="icon-trash w-3 h-3"></div>
                                    </button>

                                    {/* Status Indicator Bar */}
                                    <div className={`absolute bottom-0 left-0 w-full h-1.5 
                                        ${status === 'paid' ? 'bg-emerald-500' : ''}
                                        ${status === 'overdue' ? 'bg-red-500' : ''}
                                        ${status === 'pending' ? 'bg-blue-400' : ''}
                                        ${status === 'vacant' ? 'bg-amber-500' : ''}
                                    `}></div>
                                </div>
                            );
                        })}
                    </div>
                </div>
            )}
        </div>
    );
}