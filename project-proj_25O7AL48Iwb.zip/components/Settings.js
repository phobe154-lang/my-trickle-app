function Settings({ settings, onSave, onReset, currentUser, onLogout }) {
    const [formData, setFormData] = React.useState(settings);
    const [userLimit, setUserLimit] = React.useState(currentUser?.userLimit || 5);
    const [fontSize, setFontSize] = React.useState(settings.fontSize || 100);

    React.useEffect(() => {
        setFormData(settings);
        if (settings.fontSize) setFontSize(settings.fontSize);
    }, [settings]);

    const handleSubmit = (e) => {
        e.preventDefault();
        onSave({ ...formData, fontSize });
    };

    const handleUpdateUserLimit = () => {
        // Update global account record
        const accounts = Storage.getGlobal('accounts', []);
        const updatedAccounts = accounts.map(a => 
            a.id === currentUser.id ? { ...a, userLimit: Number(userLimit) } : a
        );
        Storage.setGlobal('accounts', updatedAccounts);
        alert(`User limit updated to ${userLimit} for this organization.`);
    };

    return (
        <div className="max-w-2xl mx-auto space-y-8 animate-fade-in">
            {/* Appearance Settings */}
            <div className="card p-6">
                <h2 className="text-xl font-bold text-slate-800 dark:text-white mb-6">Appearance</h2>
                <div className="space-y-4">
                    <div>
                        <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-3">
                            App Font Size
                        </label>
                        <div className="grid grid-cols-3 gap-3">
                            <button
                                type="button"
                                onClick={() => setFontSize(87.5)}
                                className={`px-4 py-3 rounded-lg border transition-all flex flex-col items-center justify-center gap-1 ${
                                    fontSize === 87.5 
                                    ? 'bg-sky-50 border-sky-500 text-sky-700 dark:bg-sky-900/20 dark:border-sky-500 dark:text-sky-300 ring-1 ring-sky-500' 
                                    : 'bg-white border-slate-200 text-slate-600 hover:border-slate-300 dark:bg-slate-800 dark:border-slate-700 dark:text-slate-400'
                                }`}
                            >
                                <span className="text-xs font-bold">A</span>
                                <span className="text-xs">Small</span>
                            </button>
                            
                            <button
                                type="button"
                                onClick={() => setFontSize(100)}
                                className={`px-4 py-3 rounded-lg border transition-all flex flex-col items-center justify-center gap-1 ${
                                    fontSize === 100 
                                    ? 'bg-sky-50 border-sky-500 text-sky-700 dark:bg-sky-900/20 dark:border-sky-500 dark:text-sky-300 ring-1 ring-sky-500' 
                                    : 'bg-white border-slate-200 text-slate-600 hover:border-slate-300 dark:bg-slate-800 dark:border-slate-700 dark:text-slate-400'
                                }`}
                            >
                                <span className="text-base font-bold">A</span>
                                <span className="text-xs">Medium</span>
                            </button>

                            <button
                                type="button"
                                onClick={() => setFontSize(112.5)}
                                className={`px-4 py-3 rounded-lg border transition-all flex flex-col items-center justify-center gap-1 ${
                                    fontSize === 112.5 
                                    ? 'bg-sky-50 border-sky-500 text-sky-700 dark:bg-sky-900/20 dark:border-sky-500 dark:text-sky-300 ring-1 ring-sky-500' 
                                    : 'bg-white border-slate-200 text-slate-600 hover:border-slate-300 dark:bg-slate-800 dark:border-slate-700 dark:text-slate-400'
                                }`}
                            >
                                <span className="text-xl font-bold">A</span>
                                <span className="text-xs">Large</span>
                            </button>
                        </div>
                        <p className="text-xs text-slate-500 mt-3">
                            Select a comfortable text size. Changes apply immediately after saving.
                        </p>
                    </div>
                </div>
            </div>

            {/* Admin Only Settings */}
            <div className="card p-6">
                <h2 className="text-xl font-bold text-slate-800 dark:text-white mb-6">Organization Settings</h2>
                
                {/* Only show if admin */}
                <div className="mb-6 pb-6 border-b border-slate-100 dark:border-slate-700">
                    <div className="flex justify-between items-center mb-2">
                         <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">
                            Max User Limit
                        </label>
                        <span className="text-xs bg-sky-100 text-sky-700 px-2 py-1 rounded-full font-bold">Admin Only</span>
                    </div>
                    <div className="flex gap-3">
                        <input 
                            type="number" 
                            className="input-field w-32"
                            value={userLimit}
                            onChange={e => setUserLimit(e.target.value)}
                            min="1"
                            max="50"
                        />
                        <button 
                            type="button"
                            onClick={handleUpdateUserLimit}
                            className="btn btn-secondary"
                        >
                            Update Limit
                        </button>
                    </div>
                    <p className="text-xs text-slate-500 mt-2">Control how many staff members can access this account (Simulated).</p>
                </div>

                <form onSubmit={handleSubmit} className="space-y-6">
                    <div>
                        <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">
                            Management/Company Name
                        </label>
                        <input 
                            type="text" 
                            className="input-field"
                            value={formData.managementName}
                            onChange={e => setFormData({...formData, managementName: e.target.value})}
                            placeholder="e.g. Nart Rental Management"
                        />
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">
                            Address
                        </label>
                        <input 
                            type="text" 
                            className="input-field"
                            value={formData.address}
                            onChange={e => setFormData({...formData, address: e.target.value})}
                            placeholder="Building address, City..."
                        />
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">
                            Phone Number
                        </label>
                        <input 
                            type="text" 
                            className="input-field"
                            value={formData.phone}
                            onChange={e => setFormData({...formData, phone: e.target.value})}
                            placeholder="Contact number for receipts"
                        />
                    </div>

                    <div className="pt-4 border-t border-slate-100 dark:border-slate-700 flex justify-end">
                        <button type="submit" className="btn btn-primary">
                            <div className="icon-save w-4 h-4"></div>
                            Save Changes
                        </button>
                    </div>
                </form>
            </div>

            <div className="card p-6">
                <h2 className="text-xl font-bold text-slate-800 dark:text-white mb-4">Account Info</h2>
                <div className="bg-slate-50 dark:bg-slate-900/50 p-4 rounded-lg flex justify-between items-center">
                    <div>
                        <p className="font-bold text-slate-800 dark:text-white">{currentUser?.username}</p>
                        <p className="text-sm text-slate-500">Admin: {currentUser?.adminName}</p>
                        <p className="text-xs text-slate-400 mt-1">Org: {currentUser?.orgName}</p>
                    </div>
                    <button 
                        onClick={onLogout}
                        className="btn btn-secondary border-slate-300"
                    >
                        <div className="icon-log-out w-4 h-4"></div> Logout
                    </button>
                </div>
            </div>

            <div className="card p-6 border-l-4 border-l-red-500">
                <h3 className="text-lg font-bold text-red-600 mb-2">Danger Zone</h3>
                <p className="text-slate-600 dark:text-slate-400 text-sm mb-4">
                    These actions are irreversible. Please be certain.
                </p>
                
                <div className="flex items-center justify-between bg-red-50 dark:bg-red-900/20 p-4 rounded-lg">
                    <div>
                        <h4 className="font-medium text-red-700 dark:text-red-400">Reset All Data</h4>
                        <p className="text-xs text-red-600/80 dark:text-red-400/70">Deletes all counties, areas, properties, and history.</p>
                    </div>
                    <button 
                        onClick={onReset}
                        className="px-4 py-2 bg-red-100 hover:bg-red-200 text-red-700 rounded-lg text-sm font-medium transition-colors border border-red-200"
                    >
                        Reset System
                    </button>
                </div>
            </div>
        </div>
    );
}
