function Sidebar({ activeTab, setActiveTab, isSidebarOpen, closeSidebar, openSidebar }) {
    const menuItems = [
        { id: 'dashboard', label: 'Dashboard', icon: 'layout-dashboard' },
        { id: 'properties', label: 'Properties', icon: 'building-2' },
        { id: 'tenants', label: 'Tenants', icon: 'users' },
        { id: 'settings', label: 'Settings', icon: 'settings' },
    ];

    // Swipe Logic
    React.useEffect(() => {
        let touchStartX = 0;
        let touchStartY = 0;

        const handleTouchStart = (e) => {
            touchStartX = e.changedTouches[0].screenX;
            touchStartY = e.changedTouches[0].screenY;
        };

        const handleTouchEnd = (e) => {
            const touchEndX = e.changedTouches[0].screenX;
            const touchEndY = e.changedTouches[0].screenY;
            const diffX = touchEndX - touchStartX;
            const diffY = touchEndY - touchStartY;

            // Horizontal swipe detection
            if (Math.abs(diffX) > Math.abs(diffY) && Math.abs(diffX) > 50) {
                if (diffX > 0 && touchStartX < 50) {
                    // Swipe Right from left edge -> Open
                    if (openSidebar) openSidebar();
                } else if (diffX < 0 && isSidebarOpen) {
                    // Swipe Left -> Close
                    if (closeSidebar) closeSidebar();
                }
            }
        };

        document.addEventListener('touchstart', handleTouchStart);
        document.addEventListener('touchend', handleTouchEnd);
        
        return () => {
            document.removeEventListener('touchstart', handleTouchStart);
            document.removeEventListener('touchend', handleTouchEnd);
        }
    }, [isSidebarOpen, openSidebar, closeSidebar]);

    const handleItemClick = (id) => {
        setActiveTab(id);
        // Auto-close on mobile when an item is selected
        if (window.innerWidth < 768 && closeSidebar) {
            closeSidebar();
        }
    };

    // Live Clock for Sidebar (Visible primarily on mobile or as persistent sidebar time)
    const [time, setTime] = React.useState(new Date());
    React.useEffect(() => {
        const timer = setInterval(() => setTime(new Date()), 1000);
        return () => clearInterval(timer);
    }, []);

    return (
        <>
            {/* Mobile Overlay */}
            <div 
                className={`fixed inset-0 bg-black/50 z-30 transition-opacity duration-300 md:hidden ${isSidebarOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
                onClick={closeSidebar}
            ></div>

            <aside 
                className={`
                    bg-slate-900 text-white w-64 min-h-screen flex-col transition-transform duration-300 no-print z-40
                    fixed md:static inset-y-0 left-0 shadow-xl md:shadow-none
                    ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full md:-translate-x-64 md:hidden'}
                    flex
                `}
            >
                <div className="h-16 flex items-center px-6 border-b border-slate-700 shrink-0">
                    <div className="icon-building w-6 h-6 text-sky-400 mr-3"></div>
                    <span className="font-bold text-lg tracking-wide">Nart Rental</span>
                </div>

                <nav className="flex-1 py-6 px-3 space-y-1 overflow-y-auto">
                    {menuItems.map(item => (
                        <button
                            key={item.id}
                            onClick={() => handleItemClick(item.id)}
                            className={`w-full flex items-center px-3 py-3 rounded-lg transition-colors ${
                                activeTab === item.id 
                                ? 'bg-sky-600 text-white shadow-md' 
                                : 'text-slate-400 hover:bg-slate-800 hover:text-white'
                            }`}
                        >
                            <div className={`icon-${item.icon} w-5 h-5 mr-3`}></div>
                            <span className="font-medium">{item.label}</span>
                        </button>
                    ))}
                </nav>

                <div className="p-4 border-t border-slate-800 shrink-0 space-y-4">
                    {/* Live Time Display - Especially useful for mobile where header time is hidden */}
                    <div className="px-3 py-2 bg-slate-800 rounded-lg border border-slate-700/50">
                         <div className="text-xs text-slate-400 uppercase tracking-wider font-bold mb-1">System Time</div>
                         <div className="text-xl font-mono text-sky-400 font-medium">
                            {time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                         </div>
                         <div className="text-xs text-slate-500 mt-0.5">
                            {time.toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric' })}
                         </div>
                    </div>

                    <div className="flex items-center gap-3 px-3 py-2">
                        <div className="w-8 h-8 rounded-full bg-sky-500 flex items-center justify-center text-white font-bold text-xs">
                            A
                        </div>
                        <div className="overflow-hidden">
                            <div className="text-sm font-medium truncate">Admin User</div>
                            <div className="text-xs text-slate-500 truncate">admin@nart.com</div>
                        </div>
                    </div>
                </div>
            </aside>
        </>
    );
}