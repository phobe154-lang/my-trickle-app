function SplashScreen({ isVisible }) {
    return (
        <div className={`splash-screen ${!isVisible ? 'hidden' : ''}`}>
            <img 
                src="https://app.trickle.so/storage/public/images/usr_1853a12910000001/e11e3e81-b2bb-4469-96f5-77773182e7e6.jpeg" 
                alt="Nart Rental Manager" 
                className="splash-logo"
            />
            <h1 className="text-2xl font-bold text-white mb-6 tracking-wider">Nart Rental</h1>
            <div className="loader-bar">
                <div className="loader-progress"></div>
            </div>
        </div>
    );
}