function TenantProfile({ 
    tenantId, 
    house, 
    onClose, 
    payments, 
    onAddPayment, 
    onDeleteTenant,
    onGenerateReceipt,
    settings
}) {
    if (!tenantId || !house) return null;

    // Mock getting tenant data from props - usually passed down or found
    // We need to find the tenant object from the full list if only ID is passed
    // Assuming `tenant` object is passed or we find it in parent. 
    // Let's rely on parent to pass the full tenant object for simplicity or finding it here.
    // For now, let's assume the parent component handles the data finding and passes `tenant`
    
    // Actually, looking at props, I only asked for tenantId. Let's adjust to accept tenant object or data access.
    // I will use a callback to get data or just assume `tenant` is passed as prop.
    // Let's assume `tenant` is passed.
    
    const { tenant } = house; 
    
    const [showPaymentModal, setShowPaymentModal] = React.useState(false);

    // Use Helper for status
    const nextDue = PaymentHelper.getNextDuePeriod(tenant, payments);
    const isOverdue = PaymentHelper.isOverdue(tenant, payments);
    
    // Determine visual status based on sequential logic
    const statusLabel = isOverdue ? 'Overdue' : 'Up to Date';
    const statusColor = isOverdue ? 'text-red-600 bg-red-50' : 'text-emerald-600 bg-emerald-50';
    const nextPeriodLabel = PaymentHelper.formatPeriod(nextDue.month, nextDue.year);

    // History
    const tenantPayments = payments.filter(p => p.tenantId === tenant.id).sort((a, b) => new Date(b.date) - new Date(a.date));

    // Chart Logic
    const chartRef = React.useRef(null);
    const chartInstance = React.useRef(null);

    React.useEffect(() => {
        if (chartRef.current) {
            if (chartInstance.current) {
                chartInstance.current.destroy();
            }

            const ctx = chartRef.current.getContext('2d');
            
            // Get last 6 months labels
            const labels = [];
            const dataPoints = [];
            const today = new Date();
            
            for (let i = 5; i >= 0; i--) {
                const d = new Date(today.getFullYear(), today.getMonth() - i, 1);
                const monthName = d.toLocaleString('default', { month: 'short' });
                labels.push(monthName);
                
                // Find payment for this month/year
                const monthNum = d.getMonth() + 1;
                const yearNum = d.getFullYear();
                
                const paid = payments
                    .filter(p => p.tenantId === tenant.id && p.month === monthNum && p.year === yearNum)
                    .reduce((sum, p) => sum + p.amount, 0);
                
                dataPoints.push(paid);
            }

            // Calculate dynamic font size
            const baseSize = 11; // Slightly smaller base for modal chart
            const scaleRatio = (settings?.fontSize || 100) / 100;
            const scaledFontSize = Math.round(baseSize * scaleRatio);

            const commonTickOptions = {
                color: document.documentElement.classList.contains('dark') ? '#94a3b8' : '#64748b',
                font: { size: scaledFontSize }
            };

            chartInstance.current = new ChartJS(ctx, {
                type: 'line',
                data: {
                    labels: labels,
                    datasets: [{
                        label: 'Rent Paid',
                        data: dataPoints,
                        borderColor: '#0ea5e9', // Sky 500
                        backgroundColor: 'rgba(14, 165, 233, 0.1)',
                        fill: true,
                        tension: 0.4,
                        pointBackgroundColor: '#0ea5e9',
                        pointRadius: 4
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { display: false },
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    return '$' + context.parsed.y;
                                }
                            },
                            titleFont: { size: scaledFontSize + 2 },
                            bodyFont: { size: scaledFontSize }
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            grid: {
                                color: document.documentElement.classList.contains('dark') ? '#334155' : '#e2e8f0'
                            },
                            ticks: commonTickOptions
                        },
                        x: {
                            grid: { display: false },
                            ticks: commonTickOptions
                        }
                    }
                }
            });
        }

        return () => {
            if (chartInstance.current) {
                chartInstance.current.destroy();
            }
        };
    }, [payments, tenant.id, settings?.fontSize]);

    return (
        <div className="fixed inset-0 z-50 flex items-end md:items-center justify-center bg-black/50 p-4 md:p-6 animate-fade-in print-hide-modal">
            <div className="bg-white dark:bg-slate-900 w-full max-w-4xl rounded-xl shadow-2xl max-h-[90vh] overflow-y-auto flex flex-col">
                
                {/* Header */}
                <div className="p-6 border-b border-slate-200 dark:border-slate-700 flex justify-between items-start sticky top-0 bg-white dark:bg-slate-900 z-10">
                    <div>
                        <h2 className="text-2xl font-bold text-slate-800 dark:text-white">{tenant.name}</h2>
                        <p className="text-slate-500 dark:text-slate-400 flex items-center gap-2 mt-1">
                            <span className="icon-home w-4 h-4"></span>
                            House {house.number} • Rent: ${house.rentAmount}/mo
                        </p>
                    </div>
                    <button onClick={onClose} className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full">
                        <div className="icon-x w-6 h-6"></div>
                    </button>
                </div>

                <div className="p-6 grid grid-cols-1 md:grid-cols-3 gap-8">
                    
                    {/* Left Col: Info & Actions */}
                    <div className="space-y-6">
                        <div className="card p-5">
                            <h3 className="font-semibold text-slate-700 dark:text-slate-300 mb-4 border-b border-slate-100 dark:border-slate-700 pb-2">
                                Contact Info
                            </h3>
                            <div className="space-y-3 text-sm">
                                <div className="flex items-center gap-3">
                                    <div className="icon-credit-card w-4 h-4 text-slate-400"></div>
                                    <span className="font-mono font-medium">{tenant.idNumber || 'No ID'}</span>
                                </div>
                                <div className="flex items-center gap-3">
                                    <div className="icon-phone w-4 h-4 text-slate-400"></div>
                                    <span>{tenant.phone}</span>
                                </div>
                                {tenant.email && (
                                    <div className="flex items-center gap-3">
                                        <div className="icon-mail w-4 h-4 text-slate-400"></div>
                                        <span>{tenant.email}</span>
                                    </div>
                                )}
                                <div className="flex items-center gap-3">
                                    <div className="icon-calendar w-4 h-4 text-slate-400"></div>
                                    <span>Joined {new Date(tenant.joinedDate).toLocaleDateString()}</span>
                                </div>
                                <div className="flex items-center gap-3 pt-2 border-t border-slate-100 dark:border-slate-700 mt-2">
                                    <div className="icon-shield w-4 h-4 text-emerald-500"></div>
                                    <span className="font-medium text-slate-700 dark:text-slate-300">
                                        Deposit: ${tenant.deposit ? tenant.deposit.toLocaleString() : '0'}
                                    </span>
                                </div>
                            </div>
                        </div>

                        <div className="card p-5">
                            <h3 className="font-semibold text-slate-700 dark:text-slate-300 mb-4 border-b border-slate-100 dark:border-slate-700 pb-2">
                                Payment Status
                            </h3>
                            <div className={`text-center py-4 rounded-lg ${statusColor} mb-4`}>
                                <div className="text-2xl font-bold">{statusLabel}</div>
                                <div className="text-sm opacity-80 font-medium mt-1">
                                    Next Due: {nextPeriodLabel}
                                </div>
                                <div className="text-xs opacity-70 mt-1">
                                    Due Day: {PaymentHelper.getDueDay(tenant)}{PaymentHelper.getOrdinalSuffix(PaymentHelper.getDueDay(tenant))} of month
                                </div>
                            </div>
                            
                            <button 
                                onClick={() => setShowPaymentModal(true)}
                                className="btn btn-primary w-full mb-3"
                            >
                                <div className="icon-plus w-4 h-4"></div> Pay {nextPeriodLabel}
                            </button>

                            <button 
                                onClick={() => onDeleteTenant(house.id, tenant.id)}
                                className="btn btn-secondary w-full text-red-600 border-red-200 hover:bg-red-50 dark:border-red-900 dark:hover:bg-red-900/20"
                            >
                                <div className="icon-trash-2 w-4 h-4"></div> Delete Tenant
                            </button>
                        </div>
                    </div>

                    {/* Right Col: Payment History & Chart */}
                    <div className="md:col-span-2 space-y-6">
                        {/* Chart */}
                        <div className="card p-4 h-[250px]">
                            <h3 className="text-sm font-semibold text-slate-500 dark:text-slate-400 mb-2">Payment Overview (Last 6 Months)</h3>
                            <div className="h-[200px] w-full">
                                <canvas ref={chartRef}></canvas>
                            </div>
                        </div>

                        <div className="flex justify-between items-center">
                            <h3 className="text-lg font-bold text-slate-800 dark:text-white">Payment History</h3>
                        </div>

                        <div className="bg-slate-50 dark:bg-slate-800 rounded-xl overflow-hidden border border-slate-200 dark:border-slate-700 overflow-x-auto">
                            <table className="w-full text-sm text-left whitespace-nowrap">
                                <thead className="bg-slate-100 dark:bg-slate-700/50 text-slate-600 dark:text-slate-400 font-medium">
                                    <tr>
                                        <th className="px-4 py-3">Date</th>
                                        <th className="px-4 py-3">For Month</th>
                                        <th className="px-4 py-3">Details</th>
                                        <th className="px-4 py-3">Amount</th>
                                        <th className="px-4 py-3 text-right">Receipt</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-slate-200 dark:divide-slate-700">
                                    {tenantPayments.length === 0 ? (
                                        <tr>
                                            <td colSpan="5" className="px-4 py-8 text-center text-slate-400">
                                                No payments recorded yet.
                                            </td>
                                        </tr>
                                    ) : (
                                        tenantPayments.map(pay => (
                                            <tr key={pay.id} className="hover:bg-white dark:hover:bg-slate-700/30 transition-colors">
                                                <td className="px-4 py-3">{new Date(pay.date).toLocaleDateString()}</td>
                                                <td className="px-4 py-3">
                                                    {new Date(pay.year, pay.month - 1).toLocaleDateString(undefined, {month:'long', year:'numeric'})}
                                                </td>
                                                <td className="px-4 py-3 text-xs text-slate-500">
                                                    <div>{pay.paymentMethod || 'Cash'}</div>
                                                    {pay.transactionCode && <div className="font-mono">{pay.transactionCode}</div>}
                                                </td>
                                                <td className="px-4 py-3 font-medium text-emerald-600 dark:text-emerald-400">
                                                    ${pay.amount}
                                                </td>
                                                <td className="px-4 py-3 text-right">
                                                    <button 
                                                        onClick={() => onGenerateReceipt(pay)}
                                                        className="text-sky-600 hover:text-sky-800 hover:underline inline-flex items-center gap-1"
                                                    >
                                                        <div className="icon-printer w-3 h-3"></div> Print
                                                    </button>
                                                </td>
                                            </tr>
                                        ))
                                    )}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            {showPaymentModal && (
                <PaymentModal 
                    house={house}
                    tenant={tenant}
                    targetPeriod={nextDue} // Pass the strictly calculated next period
                    onClose={() => setShowPaymentModal(false)}
                    onSubmit={(data) => {
                        onAddPayment(data);
                        setShowPaymentModal(false);
                    }}
                />
            )}
        </div>
    );
}