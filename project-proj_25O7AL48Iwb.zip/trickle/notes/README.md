# Nart Rental Management App

A comprehensive rental property management system designed to track counties, areas, apartments, houses, and tenants.

## Features
- **Multi-Account System**: Secure login for different property management accounts.
- **Property Hierarchy**: Counties > Areas > Apartments > Houses.
- **Tenant Management**: 
  - Detailed profiles with ID Number and contact info.
  - **House History**: Track occupancy timeline (Tenant A -> Vacant -> Tenant B).
  - **Move Out Logic**: Tenants can be moved out without losing payment history.
- **Financial Tracking**:
  - Rent setting per house.
  - Sequential payment tracking.
  - Receipt generation with ID number support.
- **System**:
  - Offline-capable (LocalStorage).
  - Data persistence per account.
  - Dark/Light mode.

## Tech Stack
- React 18
- Tailwind CSS
- Lucide Icons
- Chart.js