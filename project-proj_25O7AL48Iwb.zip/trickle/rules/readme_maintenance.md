When updating the project
- Always check if the changes significantly impact the project structure or features.
- If yes, update the `trickle/notes/README.md` to reflect the current state of the application.
- Ensure the README contains an overview, feature list, and basic usage instructions.