When managing data deletions
- Always ensure cascading deletes are complete.
- When an Area is deleted -> Delete all its Apartments -> Delete all their Houses -> Delete all Tenant records -> Delete all Payment history.
- No "orphaned" records should remain in the database/storage.
- Verify that state updates reflect the deletion immediately in the UI.