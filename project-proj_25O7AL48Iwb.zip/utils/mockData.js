const MOCK_DATA = {
    // Kept for reference if needed, but app now initializes empty accounts
    counties: [],
    areas: [],
    apartments: [],
    houses: [],
    tenants: [],
    payments: [],
    history: []
};
