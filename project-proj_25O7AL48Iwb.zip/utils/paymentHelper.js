const PaymentHelper = {
    /**
     * Calculates the next unpaid month/year starting from the tenant's joined date.
     * Ensures no months are skipped.
     */
    getNextDuePeriod: (tenant, payments) => {
        if (!tenant) return null;
        const joinedDate = new Date(tenant.joinedDate);
        
        // Start checking from the joined date
        let checkYear = joinedDate.getFullYear();
        let checkMonth = joinedDate.getMonth() + 1; // 1-12
        
        // Create a set of already paid "year-month" strings for O(1) lookup
        const paidPeriods = new Set(payments
            .filter(p => p.tenantId === tenant.id)
            .map(p => `${p.year}-${p.month}`));
            
        // Safety limit: Look ahead max 10 years to prevent infinite loops in edge cases
        let safetyCounter = 0;
        while (safetyCounter < 120) {
            const key = `${checkYear}-${checkMonth}`;
            if (!paidPeriods.has(key)) {
                return { month: checkMonth, year: checkYear };
            }
            
            // Move to next month
            checkMonth++;
            if (checkMonth > 12) {
                checkMonth = 1;
                checkYear++;
            }
            safetyCounter++;
        }
        return { month: checkMonth, year: checkYear }; // Default to next
    },
    
    /**
     * Determines if a tenant is overdue based on their join day.
     * Overdue if: 
     * 1. Unpaid period is in a past month
     * 2. Unpaid period is current month AND today > join day
     */
    isOverdue: (tenant, payments) => {
        if (!tenant) return false;
        const nextDue = PaymentHelper.getNextDuePeriod(tenant, payments);
        if (!nextDue) return false;
        
        const today = new Date();
        const currentYear = today.getFullYear();
        const currentMonth = today.getMonth() + 1;
        const currentDay = today.getDate();
        
        const joinedDay = new Date(tenant.joinedDate).getDate();
        
        // Logic:
        // If NextDue Year < Current Year => OVERDUE (e.g. Due 2024, Now 2025)
        if (nextDue.year < currentYear) return true;
        
        // If NextDue Year > Current Year => NOT OVERDUE (e.g. Due 2026, Now 2025)
        if (nextDue.year > currentYear) return false;
        
        // Year is same. Check Month.
        // If NextDue Month < Current Month => OVERDUE (e.g. Due Jan, Now Feb)
        if (nextDue.month < currentMonth) return true;
        
        // If NextDue Month > Current Month => NOT OVERDUE (e.g. Due Mar, Now Feb)
        if (nextDue.month > currentMonth) return false;
        
        // Month is same. Check Day.
        // If Today > JoinedDay => OVERDUE (e.g. Due on 5th, Today is 6th)
        return currentDay > joinedDay;
    },

    getDueDay: (tenant) => {
        return new Date(tenant.joinedDate).getDate();
    },

    formatPeriod: (month, year) => {
        return new Date(year, month - 1).toLocaleString('default', { month: 'long', year: 'numeric' });
    },

    getOrdinalSuffix: (i) => {
        var j = i % 10,
            k = i % 100;
        if (j == 1 && k != 11) return "st";
        if (j == 2 && k != 12) return "nd";
        if (j == 3 && k != 13) return "rd";
        return "th";
    }
};
