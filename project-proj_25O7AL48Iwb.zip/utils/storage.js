const Storage = {
    accountId: null, // Current active account
    
    setAccount: (id) => {
        Storage.accountId = id;
    },

    // Global storage for things like Account list
    getGlobal: (key, defaultVal) => {
        try {
            const item = localStorage.getItem(`nart_global_${key}`);
            return item ? JSON.parse(item) : defaultVal;
        } catch (e) { return defaultVal; }
    },
    setGlobal: (key, value) => {
        localStorage.setItem(`nart_global_${key}`, JSON.stringify(value));
    },

    // Account-scoped storage
    get: (key, defaultVal) => {
        if (!Storage.accountId) return defaultVal;
        try {
            const item = localStorage.getItem(`nart_${Storage.accountId}_${key}`);
            return item ? JSON.parse(item) : defaultVal;
        } catch (e) {
            console.error('Storage Read Error', e);
            return defaultVal;
        }
    },
    set: (key, value) => {
        if (!Storage.accountId) return;
        try {
            localStorage.setItem(`nart_${Storage.accountId}_${key}`, JSON.stringify(value));
        } catch (e) {
            console.error('Storage Write Error', e);
        }
    },

    init: (accountId) => {
        Storage.accountId = accountId;
        if (!localStorage.getItem(`nart_${accountId}_init`)) {
            // Initialize with empty or mock data for NEW accounts
            Storage.set('counties', []);
            Storage.set('areas', []);
            Storage.set('apartments', []);
            Storage.set('houses', []);
            Storage.set('tenants', []);
            Storage.set('payments', []);
            Storage.set('history', []);
            Storage.set('settings', { managementName: 'My Management', address: '', phone: '' });
            Storage.set('init', true);
        }
    }
};
